# 01 - Introdução (LEIA ANTES DE COMEÇAR)

Tempo: 05h00m00s || Quantidade de Vídeos 3

## 01 - Bem Vindo (01h40m00s)



## 03 - Bônus Elementor Pro (01h40m00s)



## 05 - Estrutura do Curso (01h40m00s)



