# 02 - Pré Requisito

Tempo: 18h20m00s || Quantidade de Vídeos 11

## 01 - Introdução (01h40m00s)



## 02 - O que é e como escolher um Domínio (01h40m00s)



## 03 - Como contratar Hospedagem (01h40m00s)



## 04 - Como Instalar o WordPress (01h40m00s)



## 05 - Instalando o Elementor (01h40m00s)



## 06 - Instalando o Elementor Pro (Maneira Oficial) (01h40m00s)



## 07 - Primeiros Passos com o Elementor (01h40m00s)



## 08 - Principais Elementos (Widgets) do Elementor (01h40m00s)



## 09 - Copiar e Colar e Colar Estilo (Dica) (01h40m00s)



## 10 - Elementor - Navigator (Dica) (01h40m00s)



## 11 - Conclusão (01h40m00s)



