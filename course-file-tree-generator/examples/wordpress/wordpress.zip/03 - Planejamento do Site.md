# 03 - Planejamento do Site

Tempo: 18h20m00s || Quantidade de Vídeos 11

## 01 - Qual o Propósito do seu Site (Tipos de Site) (01h40m00s)



## 02 - Definindo as Páginas - parte 1 (01h40m00s)



## 02 - Definindo as Páginas - parte 2 (01h40m00s)



## 03 - Criando Links (01h40m00s)



## 04 - Planejamento de uma Página (01h40m00s)



## 05 - Referências (01h40m00s)



## 06 - Brainstorm de uma Página (01h40m00s)



## 07 - Dica para visualizar melhor um layout de página (01h40m00s)



## 08 - Buscando Referências na Prática (01h40m00s)



## 09 - Principais Erros de Design (01h40m00s)



## 10 - Bônus - Templates Exclusivos (01h40m00s)



