# 04 - Manipulação de Imagens

Tempo: 20h00m00s || Quantidade de Vídeos 12

## 01 - Introdução Manipulação de Imagens (01h40m00s)



## 02 - Tamanhos e Resoluções (01h40m00s)



## 03 - Como ver a Resolução da Imagem (01h40m00s)



## 04 - Formatos de Imagens para Web (01h40m00s)



## 05 - Como ver o Formato de uma Imagem (01h40m00s)



## 06 - Bancos de Imagens (01h40m00s)



## 07 - Photoshop e Photopea (01h40m00s)



## 08 - Primeiras Impressões Photopea (01h40m00s)



## 09 - Optimizadores de Imagem (01h40m00s)



## 10 - Como Remover o Fundo de Uma Imagem com a varinha mágica (01h40m00s)



## 10 - Como Remover o Fundo de Uma Imagem (01h40m00s)



## 11 - Como Cortar uma Imagem (01h40m00s)



