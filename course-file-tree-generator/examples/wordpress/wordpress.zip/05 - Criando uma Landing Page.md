# 05 - Criando uma Landing Page

Tempo: 18h20m00s || Quantidade de Vídeos 11

## 01 - Introdução (01h40m00s)



## 02 - Configurações Iniciais (01h40m00s)



## 03 - Capa - parte 1 (01h40m00s)



## 03 - Capa - parte 2 (01h40m00s)



## 04 - Seção de Informações (01h40m00s)



## 05 - Seção de Testemunhos (01h40m00s)



## 06 - Seção de Dados (01h40m00s)



## 07 - Footer (01h40m00s)



## 08 - Otimizações para Celular (01h40m00s)



## 09 - Exportando a Página para Outros Projetos (01h40m00s)



## 10 - Print da Página (Dica Extra) (01h40m00s)



