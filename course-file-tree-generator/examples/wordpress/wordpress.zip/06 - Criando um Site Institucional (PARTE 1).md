# 06 - Criando um Site Institucional (PARTE 1)

Tempo: 38h20m00s || Quantidade de Vídeos 23

## 10 - Editando as Páginas com o Elementor (Imagens) - parte 1 (01h40m00s)



## 01 - Introdução (01h40m00s)



## 02 - PARTE 1 - Modelos Prontos ----- (01h40m00s)



## 03 - Configurações iniciais Necessárias (01h40m00s)



## 04 - Instalando o Astra e Escolhendo um Modelo (01h40m00s)



## 05 - O que mudou após a importação do modelo - parte 1 (01h40m00s)



## 05 - O que mudou após a importação do modelo - parte 2 (01h40m00s)



## 06 - Editando a Página (01h40m00s)



## 07 - Editando o Tema (01h40m00s)



## 08 - Editando o Menu (01h40m00s)



## 09 - Editando as Páginas com o Elementor (Cores) (01h40m00s)



## 10 - Editando as Páginas com o Elementor (Imagens) - parte 2 (01h40m00s)



## 11 - Editando as Páginas com o Elementor (Textos) (01h40m00s)



## 12 - Adicionando Novas Seções (01h40m00s)



## 13 - Otimizações para Celular (01h40m00s)



## 14 - Padronizando as Páginas - parte 1 (01h40m00s)



## 14 - Padronizando as Páginas - parte 2 (01h40m00s)



## 15 - Footer, Global Widget e Seções Globais - parte 1 (01h40m00s)



## 15 - Footer, Global Widget e Seções Globais - parte 2 (01h40m00s)



## 15 - Footer, Global Widget e Seções Globais - parte 3 (01h40m00s)



## 16 - Adicionando o Feed do Instagram e Outros Plugins - parte 1 (01h40m00s)



## 16 - Adicionando o Feed do Instagram e Outros Plugins - parte 2 (01h40m00s)



## 17 - Conclusão Parte 1 (01h40m00s)



