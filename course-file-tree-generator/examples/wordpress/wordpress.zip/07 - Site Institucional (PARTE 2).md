# 07 - Site Institucional (PARTE 2)

Tempo: 35h00m00s || Quantidade de Vídeos 21

## 01 - Introdução (01h40m00s)



## 02 - Referência e Planejamento - parte 1 (01h40m00s)



## 02 - Referência e Planejamento - parte 2 (01h40m00s)



## 03 - Configurações Importantes (01h40m00s)



## 04 - Página Inicial (Menu, Capa e Serviços) - parte 1 (01h40m00s)



## 04 - Página Inicial (Menu, Capa e Serviços) - parte 2 (01h40m00s)



## 04 - Página Inicial (Menu, Capa e Serviços) - parte 3 (01h40m00s)



## 05 - Página Inicial (CTA, Descrição e Clientes) - parte 1 (01h40m00s)



## 05 - Página Inicial (CTA, Descrição e Clientes) - parte 2 (01h40m00s)



## 05 - Página Inicial (CTA, Descrição e Clientes) - parte 3 (01h40m00s)



## 06 - Página Inicial (CTA, Formulário e Footer) - parte 1 (01h40m00s)



## 06 - Página Inicial (CTA, Formulário e Footer) - parte 2 (01h40m00s)



## 06 - Página Inicial (CTA, Formulário e Footer) - parte 3 (01h40m00s)



## 07 - Otimizando para Celular (01h40m00s)



## 08 - Animações e Efeitos de Movimento (01h40m00s)



## 09 - Padronizando Menu e Footer (01h40m00s)



## 10 - Página de Contato - parte 1 (01h40m00s)



## 10 - Página de Contato - parte 2 (01h40m00s)



## 10 - Página de Contato - parte 3 (01h40m00s)



## 11 - Página Sobre Nós (01h40m00s)



## 12 - Definindo a página inicial e finalização (01h40m00s)



