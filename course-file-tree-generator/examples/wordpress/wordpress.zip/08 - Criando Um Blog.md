# 08 - Criando Um Blog

Tempo: 25h00m00s || Quantidade de Vídeos 15

## 01 - Introdução (01h40m00s)



## 02 - Pra que serve um Blog (01h40m00s)



## 03 - Buscando Referências (01h40m00s)



## 04 - Criando Seu Primeiro Post (01h40m00s)



## 05 - Estruturas de Blog no WordPress (01h40m00s)



## 06 - Criando o Modelo da Página de Posts - parte 1 (01h40m00s)



## 06 - Criando o Modelo da Página de Posts - parte 2 (01h40m00s)



## 06 - Criando o Modelo da Página de Posts - parte 3 (01h40m00s)



## 07 - Escrevendo Boas Postagens (01h40m00s)



## 08 - Categorias (01h40m00s)



## 09 - Criando a Página Blog (01h40m00s)



## 10 - Usando o Widget de Posts - parte 1 (01h40m00s)



## 10 - Usando o Widget de Posts - parte 2 (01h40m00s)



## 11 - Finalizando o Layout da Página de Posts (01h40m00s)



## 12 - (Extra) Como trocar a foto de perfil do Usuário - Gravatar (01h40m00s)



