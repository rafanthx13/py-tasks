# 09 - Fazendo Uma Loja Virtual

Tempo: 56h40m00s || Quantidade de Vídeos 34

## 01 - Passos Iniciais e Conceitos Basicos - parte 1 (01h40m00s)



## 01 - Passos Iniciais e Conceitos Basicos - parte 2 (01h40m00s)



## 02 - Planejando o Seu Ecommerce (01h40m00s)



## 03 - Loja de Informatica (Astra) - parte 1 - P1 (01h40m00s)



## 03 - Loja de Informatica (Astra) - parte 2 - P1 (01h40m00s)



## 03 - Loja de Informatica (Astra) - parte 3 - P1 (01h40m00s)



## 04 - Loja de Informatica (Astra) - parte 1 - P2 (01h40m00s)



## 04 - Loja de Informatica (Astra) - parte 2 - P2 (01h40m00s)



## 05 - Paginas da Loja de Informatica (Astra) - parte 1 - P3 (01h40m00s)



## 05 - Paginas da Loja de Informatica (Astra) - parte 2 - P3 (01h40m00s)



## 06 - Loja de Informatica (Astra) - parte 1 - P4 (01h40m00s)



## 06 - Loja de Informatica (Astra) - parte 2 - P4 (01h40m00s)



## 06 - Loja de Informatica (Astra) - parte 3 - P4 (01h40m00s)



## 07 - Loja de Informatica (Astra) - parte 1 - P5 (01h40m00s)



## 07 - Loja de Informatica (Astra) - parte 2 - P5 (01h40m00s)



## 07 - Loja de Informatica (Astra) - parte 3 - P5 (01h40m00s)



## 08 - Ajustes Finais do Tema (Astra) P5 (01h40m00s)



## 09 - Loja de Doces (OceanWp) - parte 1 - P1 (01h40m00s)



## 09 - Loja de Doces (OceanWp) - parte 2 - P1 (01h40m00s)



## 10 - Pagina Inicial Loja de doces (OceanWP) - parte 1 - P2 (01h40m00s)



## 11 - Cadastrando Produtos Loja de Doces (OceanWP) - parte 1 - P3 (01h40m00s)



## 11 - Cadastrando Produtos Loja de Doces (OceanWP) - parte 2 - P3 (01h40m00s)



## 12 - Configurando Loja de Doces (OceanWP) - parte 1 - P4 (01h40m00s)



## 12 - Configurando Loja de Doces (OceanWP) - parte 2 - P4 (01h40m00s)



## 12 - Configurando Loja de Doces (OceanWP) - parte 3 - P4 (01h40m00s)



## 13 - Loja de Doces (OceanWP) - parte 1 - P5 (01h40m00s)



## 13 - Loja de Doces (OceanWP) - parte 2 - P5 (01h40m00s)



## 13 - Loja de Doces (OceanWP) - parte 3 - P5 (01h40m00s)



## 14 - Sistemas de Pagamentos - parte 1 (01h40m00s)



## 14 - Sistemas de Pagamentos - parte 2 (01h40m00s)



## 15 - Configurando SSL (IMPORTANTE) - parte 1 (01h40m00s)



## 15 - Configurando SSL (IMPORTANTE) - parte 2 (01h40m00s)



## 05 - Paginas da Loja de Informatica (Astra) - parte 3 - P3 (01h40m00s)



## 10 - Pagina Inicial Loja de doces (OceanWP) - parte 2 - P2 (01h40m00s)



