# 10 - Criando Uma Loja Virtual (Antigo)

Tempo: 26h40m00s || Quantidade de Vídeos 16

## 01 - Conceitos Básicos E-commerce (01h40m00s)



## 02 - Instalação do WooCommerce e Configuração do Wordpress (01h40m00s)



## 02-1 - Como Resetar um Site WordPress para voltar ao padrão (01h40m00s)



## 03 - Personalizando o OceanWP (01h40m00s)



## 04 - Criando Página Inicial (01h40m00s)



## 04-1 - P2 - Criando a Pagina Inicial Ecommerce (01h40m00s)



## 05 - Produto Simples (01h40m00s)



## 06 - Produto Variável (01h40m00s)



## 07 - Configurando o WooCommerce (01h40m00s)



## 08 - Configurando a Página da Loja (01h40m00s)



## 09 - Testando Nosso Ecommerce (01h40m00s)



## 10 - Adicionando Produtos à página Inicial (Shortcode) (01h40m00s)



## 11 - Adicionando Produtos à página inicial (Elementor Pro) (01h40m00s)



## 11-1 - Add Produtos Pagina Inicial Elementor Pro (01h40m00s)



## 12 - Personalizando Botões de Comprar do Woocommerce (01h40m00s)



## 13 - Sistema de Pagamentos (MercadoPago) (01h40m00s)



