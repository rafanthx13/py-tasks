# 11 - Plugins e Ferramentas Essenciais

Tempo: 10h00m00s || Quantidade de Vídeos 6

## 01 - Introdução e Visão Geral (01h40m00s)



## 02 - Duplicate Post (Duplicar Páginas e Posts) (01h40m00s)



## 03 - WP Cache (Melhorar Carregamento das Páginas) (01h40m00s)



## 04 - WordFence (Anti Vírus, Anti Malware) (01h40m00s)



## 05 - Jetpack (Análise de dados) (01h40m00s)



## 06 - UpDraft Plus (Backup Automático) (01h40m00s)



