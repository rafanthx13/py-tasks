# 12 - Email Marketing

Tempo: 21h40m00s || Quantidade de Vídeos 13

## 01 - Conceito de Construção de Lista (01h40m00s)



## 02 - Principais Ferramentas de Email Marketing (01h40m00s)



## 03 - Visão Geral do Mailchimp (01h40m00s)



## 04 - Primeiros Passos Mailchimp (01h40m00s)



## 05 - Criando Seu Primeiro Template (01h40m00s)



## 06 - Criando a Sua Primeira Lista (01h40m00s)



## 07 - Segmentos, Grupos e Tags (01h40m00s)



## 08 - Como Criar Uma Campanha Automática (01h40m00s)



## 09 - Configurando Mailchimp no Elementor (01h40m00s)



## 10 - Os 3 Tipos de Captura (01h40m00s)



## 11 - Formulário de Contato Integrado com Mailchimp (01h40m00s)



## 12 - Como Analisar Suas Campanhas (01h40m00s)



## 13 - Interface Atualizada (Mailchimp) (01h40m00s)



