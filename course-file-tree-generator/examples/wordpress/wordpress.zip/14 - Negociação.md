# 14 - Negociação

Tempo: 21h40m00s || Quantidade de Vídeos 13

## 01 - Introdução (01h40m00s)



## 02 - Portfólio (01h40m00s)



## 03 - Entendendo o Cliente (01h40m00s)



## 04 - Se Preparando para a Reunião (01h40m00s)



## 05 - Negociando (01h40m00s)



## 06 - Educando o Cliente (01h40m00s)



## 07 - Precificação (01h40m00s)



## 08 - Orçamento (01h40m00s)



## 09 - Modelo de Contrato (01h40m00s)



## 10 - Alinhamento e Entrega (01h40m00s)



## 11 - Pós Venda e Feedbacks (01h40m00s)



## 12 - MEI (Bônus) (01h40m00s)



## 13 - (Extra) Próximos Passos - Como Cobrar uma Recorrência do seu Cliente (01h40m00s)



