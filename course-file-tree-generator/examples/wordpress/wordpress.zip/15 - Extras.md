# 15 - Extras

Tempo: 11h40m00s || Quantidade de Vídeos 7

## 01 - Criando uma Página de Em Manutenção (01h40m00s)



## 02 - Certificado SSL (https) (01h40m00s)



## 03 - Como Instalar o Pixel do Facebook no seu Site - parte 1 (01h40m00s)



## 03 - Como Instalar o Pixel do Facebook no seu Site - parte 2 (01h40m00s)



## 04 - Como Criar e Configurar a Tag do Google no seu Site (01h40m00s)



## 05 - Criando Públicos no Google Ads (01h40m00s)



## 06 - Dica - Como Configurar a HotMart com o MailChimp! (ListBoss) (01h40m00s)



