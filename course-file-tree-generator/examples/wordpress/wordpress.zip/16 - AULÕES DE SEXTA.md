# 16 - AULÕES DE SEXTA

Tempo: 10h00m00s || Quantidade de Vídeos 6

## 01 - ETAPA 1 - Achando Clientes (01h40m00s)



## 02 - ETAPA 2 - Vendendo para o Cliente (01h40m00s)



## 03 - ETAPA 3 - Entregando para o Cliente (01h40m00s)



## 04 - Comece a Pensar Mobile First (01h40m00s)



## 05 - Os Segredos da Otimização (01h40m00s)



## 06 - Como Realmente se Adequar a LGPD (01h40m00s)



