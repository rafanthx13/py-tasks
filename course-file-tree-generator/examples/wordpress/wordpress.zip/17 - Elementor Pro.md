# 17 - Elementor Pro

Tempo: 61h40m00s || Quantidade de Vídeos 37

## 13 - Portfolio (Widgets Pro) (01h40m00s)



## 01 - Instalando o Elementor Pro (01h40m00s)



## 02 - Introdução (01h40m00s)



## 03 - Meus Modelos - Header e Footer (01h40m00s)



## 04 - Meus Modelos - Arquivos (01h40m00s)



## 05 - Global Widgets (01h40m00s)



## 06 - Conteúdo Dinâmico (01h40m00s)



## 07 - Função Sticky - parte 1 (01h40m00s)



## 07 - Função Sticky - parte 2 (01h40m00s)



## 08 - Integrando o MailChimp com o Forms (01h40m00s)



## 09 - Criando uma seção de Receber Novidades por Email! (com Mailchimp) (01h40m00s)



## 10 - PopUps (NOVO!) (01h40m00s)



## 11 - Menu com PopUp (01h40m00s)



## 12 - Posts (Widgets Pro) (01h40m00s)



## 14 - Gallery (Widgets Pro) (01h40m00s)



## 15 - Forms (Widgets Pro) - parte 1 (01h40m00s)



## 15 - Forms (Widgets Pro) - parte 2 (01h40m00s)



## 15-1 - Como Criar um Formulário de Contato - Com Elementor Pro (01h40m00s)



## 16 - Mult Step Form (01h40m00s)



## 17 - Login (Widgets Pro) (01h40m00s)



## 18 - NavMenu (Widgets Pro) (01h40m00s)



## 19 - Animated Headlines (Widgets Pro) (01h40m00s)



## 20 - Slide (Widgets Pro) (01h40m00s)



## 21 - Price List (Widgets Pro) (01h40m00s)



## 22 - Price Table (Widgets Pro) (01h40m00s)



## 23 - Flip Box (Widgets Pro) (01h40m00s)



## 24 - Call to Action (Widgets Pro) (01h40m00s)



## 25 - Media Carousel (Widgets Pro) (01h40m00s)



## 26 - Testimonial Carousel (Widgets Pro) (01h40m00s)



## 27 - Reviews (Widgets Pro) (01h40m00s)



## 28 - Countdown (Widgets Pro) (01h40m00s)



## 29 - Table of Contents (Widgets Pro) (01h40m00s)



## 30 - Share Buttons (Widgets Pro) (01h40m00s)



## 31 - Blockquote (Widgets Pro) (01h40m00s)



## 32 - Facebook Widgets (Widgets Pro) (01h40m00s)



## 33 - Templates (Widgets Pro) (01h40m00s)



## 34 - Lottie (Animações) (01h40m00s)



