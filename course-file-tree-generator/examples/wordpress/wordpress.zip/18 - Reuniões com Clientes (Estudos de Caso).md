# 18 - Reuniões com Clientes (Estudos de Caso)

Tempo: 05h00m00s || Quantidade de Vídeos 3

## 02 - Reunião com Cliente - Primeira Reunião (01h40m00s)



## 03 - Reunião com Cliente - Reunião de FolowUp (01h40m00s)



## 04 - Reunião com Cliente - Entrega do Site (01h40m00s)



