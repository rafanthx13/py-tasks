# 19 - Desenvolvendo um Site de Cliente

Tempo: 35h00m00s || Quantidade de Vídeos 21

## 01 - Introdução (01h40m00s)



## 02 - Domínio e Hospedagem do Cliente (01h40m00s)



## 03 - Configurações Iniciais do Projeto + Imagens - parte 1 (01h40m00s)



## 03 - Configurações Iniciais do Projeto + Imagens - parte 2 (01h40m00s)



## 03 - Configurações Iniciais do Projeto + Imagens - parte 3 (01h40m00s)



## 04 - Implementação do Layout - parte 1 (01h40m00s)



## 04 - Implementação do Layout - parte 2 (01h40m00s)



## 04 - Implementação do Layout - parte 3 (01h40m00s)



## 05 - Implementação do Layout (parte 2) - parte 1 (01h40m00s)



## 05 - Implementação do Layout (parte 2) - parte 2 (01h40m00s)



## 05 - Implementação do Layout (parte 2) - parte 3 (01h40m00s)



## 06 - Adicionando os Links (01h40m00s)



## 07 - Otimizando para Celular (01h40m00s)



## 08 - Modificações Solicitadas pelo Cliente (01h40m00s)



## 09 - Configurações de S.E.O. (Yoast e Google Search Console) - parte 1 (01h40m00s)



## 09 - Configurações de S.E.O. (Yoast e Google Search Console) - parte 2 (01h40m00s)



## 10 - Padronizando as Páginas do Tema e Exportando as Páginas (01h40m00s)



## 11 - Últimas Configurações - Preparando para a Entrega - parte 1 (01h40m00s)



## 11 - Últimas Configurações - Preparando para a Entrega - parte 2 (01h40m00s)



## 11 - Últimas Configurações - Preparando para a Entrega - parte 3 (01h40m00s)



## 12 - Conclusão (01h40m00s)



