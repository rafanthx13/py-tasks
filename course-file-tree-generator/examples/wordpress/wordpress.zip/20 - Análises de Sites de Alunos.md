# 20 - Análises de Sites de Alunos

Tempo: 13h20m00s || Quantidade de Vídeos 8

## 02 - Site de Poker - Ivan (01h40m00s)



## 03 - Site Institucional - Evandro (01h40m00s)



## 04 - Site Institucional - Alto da Toca Baterias (01h40m00s)



## 05 - Site de Vendas de um Evento - Noemy - parte 1 (01h40m00s)



## 05 - Site de Vendas de um Evento - Noemy - parte 2 (01h40m00s)



## 06 - Página de Captura - Portfólio - Cristophe (01h40m00s)



## 07 - Site do Próprio Negócio - Renato Severo - cursoterapiafloral (01h40m00s)



## 08 - Site de Cursos de Dança - Ricardo Abelhas (01h40m00s)



