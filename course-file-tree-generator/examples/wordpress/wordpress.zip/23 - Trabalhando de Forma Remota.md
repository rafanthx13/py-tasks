# 23 - Trabalhando de Forma Remota

Tempo: 13h20m00s || Quantidade de Vídeos 8

## 01 - Introdução (01h40m00s)



## 02 - Zoom (01h40m00s)



## 03 - Google Drive (01h40m00s)



## 04 - Trello (01h40m00s)



## 05 - YouCanBookMe - parte 1 (01h40m00s)



## 05 - YouCanBookMe - parte 2 (01h40m00s)



## 06 - Discord (01h40m00s)



## 07 - Slack (01h40m00s)



