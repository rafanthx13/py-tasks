# 25 - Teoria das Cores

Tempo: 01h40m00s || Quantidade de Vídeos 1

## 08 - Atualização - Salvando as Cores Padrões no Elementor (01h40m00s)



