# 26 - Como Criar um Logotipo Simples

Tempo: 08h20m00s || Quantidade de Vídeos 5

## 01 - Canva (01h40m00s)



## 02 - Logotipo - Modelo 1 (01h40m00s)



## 03 - Logotipo - Modelo 2 (01h40m00s)



## 04 - Tirando o Fundo do Logotipo e Algumas Dicas (01h40m00s)



## 05 - Bônu - Vintepila e Workana (01h40m00s)



