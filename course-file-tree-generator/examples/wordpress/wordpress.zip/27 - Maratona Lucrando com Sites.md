# 27 - Maratona Lucrando com Sites

Tempo: 05h00m00s || Quantidade de Vídeos 3

## 01 - Por que um site vale BEM mais que R$2.500 (01h40m00s)



## 02 - Ferramentas Necessárias para Criar um Site Profissional (01h40m00s)



## 03 - Como fechar seus projetos com Clientes! (01h40m00s)



